REGIONS 2025 UPDATE

Upload these 8 files into:
images/gallery/

FBLA:
fbla-regions-2025-01.jpg
fbla-regions-2025-02.jpg
fbla-regions-2025-03.jpg
fbla-regions-2025-04.jpg

DECA:
deca-regions-2025-01.jpg
deca-regions-2025-02.jpg
deca-regions-2025-03.jpg
deca-regions-2025-04.jpg

Then replace your current gallery.html with the one in this package.

Updated:
- FBLA Regions album -> 2025 link
- DECA Regions album -> 2025 link
- Removed "2024 Archive" wording
- "View 2024 Album" -> "View Full Album"
- Replaced both sets of 4 preview photos with the new 2025 photos

No styles.css or script.js changes are required.
